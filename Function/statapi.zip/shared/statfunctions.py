import logging

def object_array_sort(req_body):
    logging.info('Loading sortObject Array')
    data = req_body.get('data')
    order = req_body.get('sortorder')
    sortkeys = req_body.get('sortkeys')

    if len(data) == 0:
        return {'outData': [], 'outStatus': 200}

    if order == 'desc':
        reverseOrder = True
    else:
        reverseOrder = False

    try: 
        outData = sorted(data, key=lambda x: tuple(x[key] for key in sortkeys), reverse=reverseOrder)
    except:
        outData = {'Error': 'Unable to sort, check to confirm the sortkey is valid.'}
        outStatus=400
    else:
        outStatus = 200
    return {'outData': outData, 'outStatus': outStatus}

def change_property_case(req_body):
    logging.info('Loading changePropertyCase Array')
    data = req_body.get('data')
    case = req_body.get('case')
    properties = req_body.get('properties')

    try:
        if case == 'title':
            for prop in properties:
                data[prop] = ' '.join(elem.capitalize() for elem in data[prop].split())
        elif case == 'upper':
            for prop in properties:
                data[prop] = data[prop].upper()
        elif case == 'lower':
            for prop in properties:
                data[prop] = data[prop].lower()
    except:
        pass

    return {'outData': data, 'outStatus': 200}

def process_sentinel_data(req_body):

    logging.info('Loading processSentinelData')
    data = req_body.get('data')
    columns = data['tables'][0]['columns']
    rows = data['tables'][0]['rows']
    columnlist = []
    query_results = []

    for column in columns:
        columnlist.append(column['name'])
    
    for row in rows:
        query_results.append(dict(zip(columnlist,row)))

    return {'outData': query_results, 'outStatus': 200}

def return_highest_item(req_body):

    logging.info('Loading returnHighestItem')
    data = req_body.get('data')
    #ordered_list = req_body.get('orderedList') or ['High','Medium','Low','Informational','Unknown']
    ordered_list = req_body.get('orderedList', ['High','Medium','Low','Informational','Unknown'])
    
    if data is None:
        return {'outData': {'Error': 'Unable to find highest item, no data array provided'}, 'outStatus': 400}

    unsorted_list = [x.lower() for x in data]
    out = None

    for item in ordered_list:
        if item.lower() in unsorted_list:
            out = item
            break

    if out is None:
        out = 'Unknown'

    return {'outData': out, 'outStatus': 200, 'outType': 'text'}    