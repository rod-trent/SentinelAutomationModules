import logging

def object_array_sort(req_body):
    logging.info('Loading sortObject Array')
    data = req_body.get('data')
    order = req_body.get('sortorder')
    sortkeys = req_body.get('sortkeys')

    if len(data) == 0:
        return {'outData': [], 'outStatus': 200}

    if order == 'desc':
        reverseOrder = True
    else:
        reverseOrder = False

    try: 
        outData = sorted(data, key=lambda x: tuple(x[key] for key in sortkeys), reverse=reverseOrder)
    except:
        outData = {'Error': 'Unable to sort, check to confirm the sortkey is valid.'}
        outStatus=400
    else:
        outStatus = 200
    return {'outData': outData, 'outStatus': outStatus}

def change_property_case(req_body):
    logging.info('Loading changePropertyCase Array')
    data = req_body.get('data')
    case = req_body.get('case')
    properties = req_body.get('properties')

    try:
        if case == 'title':
            for prop in properties:
                data[prop] = ' '.join(elem.capitalize() for elem in data[prop].split())
        elif case == 'upper':
            for prop in properties:
                data[prop] = data[prop].upper()
        elif case == 'lower':
            for prop in properties:
                data[prop] = data[prop].lower()
    except:
        pass

    return {'outData': data, 'outStatus': 200}

