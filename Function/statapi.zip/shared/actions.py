from shared import statfunctions as stat

def initiate_action(action, req_body):
    actions = {
        'sortObjectArray': stat.object_array_sort(req_body),
        'warmFunction': {'outData': {}, 'outStatus': 200}
    }
    return actions.get(action, {'outData': {'Error': 'Invalid Action'}, 'outStatus': 400})