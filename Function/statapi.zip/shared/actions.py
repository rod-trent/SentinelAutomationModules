from shared import statfunctions as stat

def initiate_action(action, req_body):
    
    if action == 'sortObjectArray':
        outData = stat.object_array_sort(req_body)
    elif action == 'changePropertyCase':
        outData = stat.change_property_case(req_body)
    else:
        outData = {'outData': {'Error': 'Invalid Action'}, 'outStatus': 400}
    
    return outData