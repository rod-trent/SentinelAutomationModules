import logging
import json
from shared import actions
import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('STAT Helper starting...')

    try:
        req_body = req.get_json()
    except ValueError:
        logging.error('Could not parse body')
        return func.HttpResponse(json.dumps({'Error': 'Invalid Request Body'}), status_code=500)
    else:
        action = req_body.get('action')

    try:
        outObject = actions.initiate_action(action, req_body)
    except:
        logging.error('Unexpected error')
        return func.HttpResponse(json.dumps({'Error': 'Unknown error'}), status_code=500)

    return func.HttpResponse(json.dumps(outObject['outData']), mimetype="application/json", status_code=outObject['outStatus'])
